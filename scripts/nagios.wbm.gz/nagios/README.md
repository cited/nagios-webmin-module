# Info
Webmin module for managing Nagios.

# How to install
Archive module

	$ git clone http://git.sh8.eu/LymonHead/webmin_nagios
	$ mv webmin_nagios-master nagios
	$ tar -cvzf nagios.wbm.gz nagios/

Upload from Webmin->Webmin Configuration->Webmin Modules

Tested on Ubuntu 18.04 and CentOS 7.7
